package crosswritecanary

// CrossWriteMarker is an inert marker that exists only in the controlled test ZIP.
const CrossWriteMarker = "hi from robert - first owned package wrote second owned package canary"
